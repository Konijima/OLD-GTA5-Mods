﻿using GTA;
using GTA.Native;
using System;

namespace ImmersiveVehicleControls
{
    public class Main : Script
    {
        private Boolean CanRemoteStartVehicle = true;

        private Control EnterControl = Control.Enter;
        private Control VehicleExitControl = Control.VehicleExit;

        private bool enforceShutEngine = false;
        private int enterControlDownTime = 0;
        private int vehicleExitControlDownTime = 0;

        public Main()
        {
            Tick += Main_Tick;
        }

        private void Main_Tick(object sender, EventArgs e)
        {
            if (!Game.Player.Character.IsInVehicle()) enforceShutEngine = false;

            // EnterControl
            if (Game.IsEnabledControlPressed(0, EnterControl)) enterControlDownTime++;
            if (Game.IsEnabledControlJustReleased(0, EnterControl)) enterControlDownTime = 0;

            // VehicleExitControl
            if (Game.IsEnabledControlPressed(0, VehicleExitControl)) vehicleExitControlDownTime++;
            if (Game.IsEnabledControlJustReleased(0, VehicleExitControl)) vehicleExitControlDownTime = 0;

            // ACTION: Remote Start Engine & Enter Vehicle
            if (CanRemoteStartVehicle && !Game.Player.Character.IsInVehicle())
            {
                if (Game.Player.Character.GetVehicleIsTryingToEnter().Exists())
                {
                    Vehicle targetVehicle = Game.Player.Character.GetVehicleIsTryingToEnter();

                    if (enterControlDownTime < 30) return;
                    if (targetVehicle.EngineRunning) return;
                    if (targetVehicle.NeedsToBeHotwired) return;
                    if (!targetVehicle.PreviouslyOwnedByPlayer) return;

                    BeepVehicle(targetVehicle, 2, 75, 125);
                    Script.Wait(100);
                    targetVehicle.EngineRunning = true;
                }
            }

            // ACTION: Stop Engine & Leave Vehicle
            if (Game.Player.Character.IsInVehicle())
            {
                if (Game.Player.Character.SeatIndex == VehicleSeat.Driver)
                {
                    Vehicle vehicle = Game.Player.Character.CurrentVehicle;

                    if (IsSubttaskActive(Game.Player.Character, Subtask.EXITING_VEHICLE_OPENING_DOOR_EXITING) && vehicleExitControlDownTime > 30)
                    {
                        enforceShutEngine = true;
                    }

                    if (IsSubttaskActive(Game.Player.Character, Subtask.EXITING_VEHICLE_OPENING_DOOR_EXITING) && enforceShutEngine)
                    {
                        vehicle.EngineRunning = false;
                    }
                    if (IsSubttaskActive(Game.Player.Character, Subtask.EXITING_VEHICLE_OPENING_DOOR_EXITING) && !enforceShutEngine)
                    {
                        vehicle.EngineRunning = true;
                    }
                }
            }
        }

        public void BeepVehicle(Vehicle targetVehicle, int count = 1, int length = 100, int delay = 100)
        {
            count = (count >= 1) ? count : 1;
            for (var x = 0; x < count; x++)
            {
                targetVehicle.SoundHorn(length);
                Script.Wait(delay);
            }
        }
        public Boolean IsSubttaskActive(Ped ped, Subtask task)
        {
            return Function.Call<bool>(Hash.GET_IS_TASK_ACTIVE, ped, (int)task);
        }
    }
    
    public enum Subtask
    {
        AIMED_SHOOTING_ON_FOOT = 4,
        GETTING_UP = 16,
        MOVING_ON_FOOT_NO_COMBAT = 35,
        MOVING_ON_FOOT_COMBAT = 38,
        USING_LADDER = 47,
        CLIMBING = 50,
        GETTING_OFF_SOMETHING = 51,
        SWAPPING_WEAPON = 56,
        REMOVING_HELMET = 92,
        DEAD = 97,
        MELEE_COMBAT = 130,
        HITTING_MELEE = 130,
        SITTING_IN_VEHICLE = 150,
        DRIVING_WANDERING = 151,
        EXITING_VEHICLE = 152,

        ENTERING_VEHICLE_GENERAL = 160,
        ENTERING_VEHICLE_BREAKING_WINDOW = 161,
        ENTERING_VEHICLE_OPENING_DOOR = 162,
        ENTERING_VEHICLE_ENTERING = 163,
        ENTERING_VEHICLE_CLOSING_DOOR = 164,

        EXITING_VEHICLE_OPENING_DOOR_EXITING = 167,
        EXITING_VEHICLE_CLOSING_DOOR = 168,
        DRIVING_GOING_TO_DESTINATION_OR_ESCORTING = 169,
        USING_MOUNTED_WEAPON = 199,
        AIMING_THROWABLE = 289,
        AIMING_GUN = 290,
        AIMING_PREVENTED_BY_OBSTACLE = 299,
        IN_COVER_GENERAL = 287,
        IN_COVER_FULLY_IN_COVER = 288,

        RELOADING = 298,

        RUNNING_TO_COVER = 300,
        IN_COVER_TRANSITION_TO_AIMING_FROM_COVER = 302,
        IN_COVER_TRANSITION_FROM_AIMING_FROM_COVER = 303,
        IN_COVER_BLIND_FIRE = 304,

        PARACHUTING = 334,
        PUTTING_OFF_PARACHUTE = 336,

        JUMPING_OR_CLIMBING_GENERAL = 420,
        JUMPING_AIR = 421,
        JUMPING_FINISHING_JUMP = 422,
    }
}
